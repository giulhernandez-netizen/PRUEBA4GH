#lista vacia :)
productos = []
#definiciones :)
def validar_nombre(nombre):
  if nombre.strip() == "":
    return False
  return True

def validar_stock(stock_str):
  try:
    stock = int(stock_str)
    if stock >= 0:
      return True
    return False
  except ValueError:
    return False

def validar_precio(precio_str):
  try:
    precio = float(precio_str)
    if precio > 0:
      return True
    return False
  except ValueError:
    return False

def mostrar_menu():
  print("\n==========MENU PRINCIPAL==========")
  print("1.agregar producto")
  print("2.Buscar producto")
  print("3.Eliminar producto")
  print("4.Actualizar disponibilidad")
  print("5.Mostrar productos")
  print("6.Salir")
  print("====================================")

def leer_opcion():
  try:
    opcion = int(input("elija una opcion(1/6): "))
    return opcion
  except ValueError:
    return -1

def agregar_producto(lista_productos):
  print("\n =========REGISTRO DE PRODUCTOS==========")
  nombre = input("ingrese el nombre del producto: ")
  stock_raw = input("ingrese el stock (que sea mayor o igual a 0): ")
  precio_raw = input("ingrese el precio del producto: ")

  if not validar_nombre(nombre):
    print("error:la descripcion no puede estar vacia ni contener solamente espacios...")
    return

  if not validar_stock(stock_raw):
    print("error:el stock debe ser un numero entero mayor o igual que cero...")
    return

  if not validar_precio(precio_raw):
    print("error: el precio del producto debe ser un numero decimal mayor que cero....")
    return

  nuevo_producto = {
    "nombre": nombre,
    "stock": int(stock_raw),
    "precio": float(precio_raw),
    "disponible": False 
  }

  lista_productos.append(nuevo_producto)
  print("El producto fue registrado exitosamente")

def buscar_producto(lista_productos, nombre_buscar):
  for i in range(len(lista_productos)):
    if lista_productos[i]["nombre"] == nombre_buscar:
      return i 
  return -1 

def actualizar_disponibilidad(lista_productos):
  for producto in lista_productos:
    if producto["stock"] > 0:
      producto["disponible"] = True
    else:
      producto["disponible"] = False



def mostrar_productos(lista_productos):
  actualizar_disponibilidad(lista_productos)
  print("\n=== lista de productos ===")
  if len(lista_productos) == 0:
    print("no hay productos registrados actualmente.")
    return

  for producto in lista_productos:
    if producto["disponible"] == True:
      estado_texto = "DISPONIBLE"
    else:
      estado_texto = "SIN STOCK"
     
    print(f"\nNombre: {producto['nombre']}")
    print(f"Stock: {producto['stock']}")
    print(f"Precio: {producto['precio']}")
    print(f"Estado: {estado_texto}")
    print("****************************************")

#bucle while :)
while True:
  mostrar_menu()
  opcion = leer_opcion()
  if opcion == 1:
    agregar_producto(productos)

  elif opcion == 2:
    print("\n=====BUSCAR PRODUCTO======")
    nombre_buscar = input("ingrese el nombre exacto a buscar(debe ser igual): ")
    posicion = buscar_producto(productos, nombre_buscar)
    
    if posicion != -1:
      producto = productos[posicion]
      if producto["disponible"] == True:
        estado_texto = "DISPONIBLE"
      else:
        estado_texto = "SIN STOCK"


      print(f"\ntarea encontrada en la posicion: {posicion}")
      print(f"Nombre: {producto['nombre']}")
      print(f"Stock: {producto['stock']}")
      print(f"Precio: {producto['precio']}")
      print(f"Estado: {estado_texto}")
    else:
      print("el producto no se encuentra registrada en estos momentos.")

  elif opcion == 3:
    print("\n======ELIMINAR PRODUCTO======")
    nombre_eliminar = input("ingrese la descripcion de el producto que desea eliminar: ")
    posicion = buscar_producto(productos, nombre_eliminar)

    if posicion != -1:
      productos.pop(posicion)
      print("el producto fue eliminada exitosamente")
    else:
      print(f"\nel producto '{nombre_eliminar}' no se encuentra registrado.")
  elif opcion == 4:
    actualizar_disponibilidad(productos)
    print("\nestados actualizados segun su prioridad.")
  elif opcion == 5:
    mostrar_productos(productos)
  elif opcion == 6:
    print('\nGracias por usar el sistema. vuelva pronto')
    break 
  else:
    print("ERROR: intente nuevamente con un numero del 1 al 6.")